#sum  of digit
t=int(input("enter"))
while t>0:
    n=int(input("enter"))
    s=0
    while n!=0:
        r=n%10
        s=s+r
        n=n//10
    print("sum of digits",s)
    t-=1    