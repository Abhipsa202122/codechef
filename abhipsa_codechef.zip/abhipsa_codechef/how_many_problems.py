# how many unattempted problems
x,y=map(int,input().split())
unattempted=x-y
print(unattempted)