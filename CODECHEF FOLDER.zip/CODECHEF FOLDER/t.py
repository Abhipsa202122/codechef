#Total prize money
T=int(input())
for i in range(T):
    X,Y=map(int,input().split())
    s=X*10+Y*90
    print(s)
