#playlist
T=int(input("Enter"))
for i in range(T):
    A,B=map(int,input().split())
    C=B*3
    D=A//C
    print(D)
        
